"""
basically any penalty kicking states in here 

quick_tap, slow_tap

conversion , trois

pen_punt, free_kick_punt


"""