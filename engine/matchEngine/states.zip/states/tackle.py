"""
as well as an action a tackle is a state. 
players have new options unavcailable else where based on outcome of tackle
can leg-drive offload or attempt to score 

"""