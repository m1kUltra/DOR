# states/restart.py — flags only

KICK_OFF      = "reastart.kick_off"   # NOTE: kept your exact tag (typo included) because ACTION_MATRIX is god
DROP_22       = "restart.22Drop"
GOAL_LINE      = "Goal_line"
RESTART_TAGS = {
    KICK_OFF,
    DROP_22,
    GOAL_LINE 
}
