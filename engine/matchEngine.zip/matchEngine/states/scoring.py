# states/scoring_state.py — flags only

# kept exactly as in ACTION_MATRIX
CHECK_TRY = "score.check_try"

SCORING_TAGS = {
    CHECK_TRY,
}