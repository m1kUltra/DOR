# states/ruck.py — flags only

START = "ruck.start"

RUCK_TAGS = {
    START,
}
