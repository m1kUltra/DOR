# states/lineout.py — flags only

START = "lineout.start"

LINEOUT_TAGS = {
    START,
}
