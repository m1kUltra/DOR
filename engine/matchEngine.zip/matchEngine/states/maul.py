# states/maul.py — flags only

START = "maul.start"

MAUL_TAGS = {
    START,
}


"""2 types choke_tackle, rolling_maul"""