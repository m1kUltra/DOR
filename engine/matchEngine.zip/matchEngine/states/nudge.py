"""
basically any penalty kicking states in here 

quick_tap, slow_tap

conversion , trois

pen_punt, free_kick_punt


"""
# states/nudge.py — flags only

QUICK_TAP   = "nudge.quick_tap"
SLOW_TAP    = "nudge.slow_tap"
CONVERSION  = "nudge.conversion"
PEN_PUNT    = "nudge.pen_punt"
FREE_KICK   = "nudge.free_kick_punt"

NUDGE_TAGS = {
    QUICK_TAP,
    SLOW_TAP,
    CONVERSION,
    PEN_PUNT,
    FREE_KICK,
}
