# states/scrum.py — flags only

START = "scrum.start"

SCRUM_TAGS = {
    START,
}
