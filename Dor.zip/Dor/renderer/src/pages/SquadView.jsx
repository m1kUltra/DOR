import React from "react";
import "./SquadView.css"
export default function SquadView() {
  return (
    <div className="screen">
      <h2>Squad View</h2>
      <p>List of players and team information goes here.</p>
    </div>
  );
}
