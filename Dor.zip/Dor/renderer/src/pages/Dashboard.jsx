import React from "react";
import "./Dashboard.css";
export default function Dashboard() {
  return (
    <div className="screen">
      <h2>Dashboard</h2>
      <p>Welcome to the Director of Rugby dashboard.</p>
    </div>
  );
}
