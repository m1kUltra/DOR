import React from "react";

export default function RecruitmentHub() {
  return (
    <div className="screen">
      <h2>Recruitment Hub</h2>
      <p>Scout and sign players from here.</p>
    </div>
  );
}
