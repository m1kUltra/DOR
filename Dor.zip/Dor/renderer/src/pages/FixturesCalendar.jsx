import React from "react";

export default function FixturesCalendar() {
  return (
    <div className="screen">
      <h2>Fixtures & Calendar</h2>
      <p>Upcoming matches and events calendar.</p>
    </div>
  );
}
