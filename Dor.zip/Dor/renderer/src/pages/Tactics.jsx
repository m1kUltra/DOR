import React from "react";

export default function Tactics() {
  return (
    <div className="screen">
      <h2>Tactics</h2>
      <p>Manage formations and tactical instructions.</p>
    </div>
  );
}
